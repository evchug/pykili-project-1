from flask import Flask, render_template, request

import json

from natasha.markup import format_json

from natasha import (
    NamesExtractor,
    AddressExtractor,
    DatesExtractor,
    LocationExtractor
)


Name = NamesExtractor()
Add = AddressExtractor()
Dat = DatesExtractor()
Loc = LocationExtractor()

extractors = [
    Name,
    Add,
    Dat,
    Loc
]

def Names(text):
    facts = []
    matches = Name(text)
    facts.extend(_.fact.as_json for _ in matches)
    result = json.loads(format_json(facts))
    return result

def Dates(text):
    facts = []
    matches = Dat(text)
    facts.extend(_.fact.as_json for _ in matches)
    result = json.loads(format_json(facts))
    return result

def Locs(text):
    facts_add = []
    facts_loc = []
    matches_add = Add(text)
    matches_loc = Loc(text)
    facts_add.extend(_.fact.as_json for _ in matches_add)
    facts_loc.extend(_.fact.as_json for _ in matches_loc)
    result_add = json.loads(format_json(facts_add))
    result_loc = json.loads(format_json(facts_loc))
    result = result_add + result_loc
    return result

def All(text):
    facts = []
    for extractor in extractors:
        matches = extractor(text)
        facts.extend(_.fact.as_json for _ in matches)
    result = json.loads(format_json(facts))
    return result




app = Flask(__name__)
    

@app.route('/', methods=["GET"])
def main():
    return render_template('main.html')


@app.route('/',methods=["POST"])
def process():
    if request.method=="POST":
        choice = request.form['taskoption']
        text = request.form['rawtext']
        if choice == 'name':
            results = Names(text)
            num_of_results = len(results)
        elif choice == 'date':
            results = Dates(text)
            num_of_results = len(results)
        elif choice == 'location':
            results = Locs(text)
            num_of_results = len(results)
        elif choice == 'all':
            results = All(text)
            num_of_results = len(results)
    return render_template('main.html', text=text, results=results, num_of_results=num_of_results)


if __name__ == '__main__':
    import os
    HOST = os.environ.get('SERVER_HOST', 'localhost')
    try:
        PORT = int(os.environ.get('SERVER_PORT', '5555'))
    except ValueError:
        PORT = 5555
    app.run(HOST, PORT)
